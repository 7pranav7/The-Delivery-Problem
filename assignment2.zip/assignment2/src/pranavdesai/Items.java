package pranavdesai;

public class Items {
	
	public int weight;
	public int value;
	public String lbl;
	
	public Items(String lbl, int weight, int value) {
		// TODO Auto-generated constructor stub
		this.lbl = lbl;
		this.weight = weight;
		this.value = value;
	}
}
