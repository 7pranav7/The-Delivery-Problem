package pranavdesai;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class MainRun {
	
	public static ArrayList<Pop> loadInputData(String path){
		ArrayList<Pop> pop = new ArrayList<Pop>();
		File input = new File("input.txt");
		Scanner sc;
		Pop current = null;
		try {
			sc = new Scanner(input);
			String curr = sc.nextLine();
			while(sc.hasNextLine()) {
				if(curr.equals("\n")|| curr.equals(""))
				{
					curr = sc.nextLine();
					continue;
				}
				else{
					
					if(curr.equals("***"))
					{
						sc.hasNextLine();
						int capacity = sc.nextInt();
						int quota = sc.nextInt();
						int size = sc.nextInt();
						pop.add(new Pop(capacity, quota, 10));
						current = pop.get(pop.size()-1);
						curr = sc.nextLine();
					}
					else {
						current.insert(curr);
						curr = sc.nextLine();
					}
				}
			}
		} catch (FileNotFoundException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		System.out.println("Input data has been loaded successfully");
		return pop;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Pop> pop = loadInputData("input.txt");
		Scanner sc = new Scanner(System.in);
		for (int i = 0; i < pop.size(); i++) {
			System.out.println("Population number "+(i+1));
			pop.get(i).run();
			System.out.println("Do you want to load the next population? (Y/N)");
			String input = sc.nextLine();
			if(input.equalsIgnoreCase("y")) {
				if(i==pop.size()-1) {
					System.out.println("The end of the input file");
					break;
				}
				else {
					continue;
				}
			}
			else {
				System.out.println("Exiting program");
				break;
			}
		}
	}

}
