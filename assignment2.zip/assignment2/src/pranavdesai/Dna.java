package pranavdesai;

import java.util.ArrayList;
import java.util.concurrent.ThreadLocalRandom;

public class Dna implements Comparable<Dna> {
	
	public int weight;
	public int fitness;
	public ArrayList<Integer> gene;
	
	public Dna(ArrayList<Integer> gene) {
		// TODO Auto-generated constructor stub
		this.gene = new ArrayList<Integer>(gene);
	}
	
	public Dna() {
		// TODO Auto-generated constructor stub
		this.gene = new ArrayList<Integer>();
	}
	
	@Override
	public int compareTo(Dna o) {
		// TODO Auto-generated method stub
		if (this.fitness<o.fitness) {
			return 1;
		}
		else if (this.fitness == o.fitness) {
			return 0;
		}
		else {
			return -1;
		}
	}
	
	public Dna crossover(Dna spouse) {
		Dna child = new Dna();
		int mid = ThreadLocalRandom.current().nextInt(gene.size());
		if (ThreadLocalRandom.current().nextInt(1)<0.8) {
			for (int i = 0; i < gene.size(); i++) {
				if (i>mid) {
					child.gene.add(gene.get(i));
				}
				else {
					child.gene.add(spouse.gene.get(i));
				}
			}
		}
		return child;
	}
	
	public void mutate(double rate) {
		for (int i = 0; i < gene.size(); i++) {
			if(ThreadLocalRandom.current().nextInt(1)<rate) {
				gene.set(i, ThreadLocalRandom.current().nextInt(0,2));
			}
		}
	}

}
