package pranavdesai;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.concurrent.ThreadLocalRandom;

import javax.print.attribute.HashAttributeSet;

public class Pop {
	
	private int capacity;
	private int quota;
	private ArrayList<Dna> pop;
	private ArrayList<Items> items;
	private ArrayList<String> popData;
	private int maxItems;
	private int popSize;
	private int maxPopSize;
	private float mutationRate = 0.01f;
	
	public Pop(int capacity, int qouta, int popSize) {
		this.capacity = capacity;
		this.quota = qouta;
		this.popSize = popSize;
		this.maxPopSize = 1000;
		this.popData = new ArrayList<String>();
		this.pop = new ArrayList<Dna>();
		this.items = new ArrayList<Items>();
	}
	
	public void insert(String member) {
		popData.add(member);
	}
	
	public void generate() {
		ArrayList<Integer> gene = new ArrayList<Integer>();
		for (int i = 0; i < popData.size(); i++) {
			String [] data = popData.get(i).split(" ");
			ArrayList<String> listData = new ArrayList<String>();
			for (String string : data) {
				listData.add(string);
			}
			for (int j = 0; j < listData.size(); j++) {
				String curr = listData.get(j);
				if (curr.equals("")) {
					listData.remove(j);
				}
			}
			items.add(new Items(listData.get(0), Integer.parseInt(listData.get(1)), Integer.parseInt(listData.get(2))));
		}
		for (int i = 0; i < popSize; i++) {
			for (int j = 0; j < popData.size(); j++) {
				int random = ThreadLocalRandom.current().nextInt(0,2);
				gene.add(random);
			}
			Dna newDna = new Dna(gene);
			pop.add(newDna);
			gene.clear();
		}
	}
	
	public void calcFitness() {
		for (int i = 0; i < pop.size(); i++) {
			Dna selected = pop.get(i);
			int totalW = 0;
			int totalV = 0;
			for (int j = 0; j < items.size(); j++) {
				if (selected.gene.get(j)==1) {
					totalW += items.get(j).weight;
					totalV += items.get(j).value;
				}
			}
			if (totalW>capacity) {
				selected.fitness = 0;
			}
			else {
				selected.fitness = totalV;
				selected.weight = totalW;
			}
		}
		Collections.sort(pop);
	}
	
	public void calcFitness(Dna dna) {
		for (int i = 0; i < pop.size(); i++) {
			Dna selected = dna;
			int totalW = 0;
			int totalV = 0;
			for (int j = 0; j < items.size(); j++) {
				if (selected.gene.get(j)==1) {
					totalW += items.get(j).weight;
					totalV += items.get(j).value;
				}
			}
			if (totalW>capacity) {
				selected.fitness = 0;
			}
			else {
				selected.fitness = totalV;
				selected.weight = totalW;
			}
		}
	}
	
	public void clear() {
		pop.clear();
		items.clear();
	}
	
	public ArrayList<Dna> roulette(){
		Dna parent1 = null;
		Dna parent2 = null;
		
		parent1 = pop.get(ThreadLocalRandom.current().nextInt(0,pop.size()));
		parent2 = pop.get(ThreadLocalRandom.current().nextInt(0,pop.size()));
		
		ArrayList<Dna> parents = new ArrayList<Dna>();
		parents.add(parent1);
		parents.add(parent2);
		return parents;
	}
	
	public ArrayList<Dna> tournemant(int num){
		int numberOfMembers = num;
		int startingPosition = 0;
		int numberOfMembersCompleted = 0;
		ArrayList<Dna> winners = new ArrayList<Dna>();
		ArrayList<Dna> particpants = new ArrayList<Dna>();
		
		while (!(num>=pop.size())) {
			for (int i = startingPosition; i < num; i++) {
				particpants.add(pop.get(i));
				numberOfMembersCompleted++;
			}
			Collections.sort(particpants);
			winners.add(particpants.get(0));
			startingPosition = num;
			num += numberOfMembers;
			particpants.clear();
		}
		for (int i = startingPosition; i < pop.size(); i++) {
			particpants.add(pop.get(i));
			numberOfMembersCompleted++;
		}
		Collections.sort(particpants);
		winners.add(particpants.get(0));
		Collections.sort(winners);
		ArrayList<Dna> firstTwo = new ArrayList<Dna>();
		if(winners.size()==1) {
			winners.add(particpants.get(1));
		}
		else {
			firstTwo.add(winners.get(1));
		}
		firstTwo.add(winners.get(0));
		firstTwo.add(winners.get(1));
		return firstTwo;
	}
	
	public void reproduction() {
		popSize = pop.size();
		
		for (int i = 0; i < popSize; i++) {
			ArrayList<Dna> parents = tournemant(10);
			Dna child = parents.get(0).crossover(parents.get(1));
			child.mutate(mutationRate);
			calcFitness(child);
			pop.add(child);
		}
		if (pop.size()>=5000) {
			Collections.sort(pop);
			for (int i = pop.size()-1; i > pop.size()/2; i--) {
				pop.remove(i);
			}
		}
	}
	
	public void run() {
		generate();
		calcFitness();
		int fitnessOfCurentGen = 0;
		int gen = 1;
		int genCurrRound = 1;
		int soluFitness = 0;
		int soluGen = 0;
		int maxGen = 500;
		int maxGenPerRound = 200;
		Dna fittest = pop.get(0);
		HashMap<Integer, Integer> gens = new HashMap<Integer, Integer>();
		
		while(true) {
			calcFitness();
			fittest = pop.get(0);
			reproduction();
			fitnessOfCurentGen = fittest.fitness;
			
			if (gen%1 == 0) {
				System.out.println("Generation: "+gen+" Fittest of the generation: "+fitnessOfCurentGen+" Population: "+pop.size());
			}
			if(soluFitness<fitnessOfCurentGen) {
				soluFitness = fitnessOfCurentGen;
				soluGen = gen;
			}
			
			gen++;
			genCurrRound++;
			
			if (genCurrRound==maxGenPerRound) {
				if (fittest.fitness<quota) {
					genCurrRound = 0;
				}
				if (gen == maxGen) {
					break;
				}
				else {
					break;
				}
			}
		}
		
		popSize = pop.size();
		Collections.sort(pop);
		
		System.out.println("Total number of generations: "+ gen+"\nBest Solution with given parameters");
		System.out.println("Solution generation: "+soluGen+"\nSolution fitness: "+soluFitness);
		System.out.println("Value: "+pop.get(0).fitness);
		System.out.println("Weight: "+pop.get(0).weight);
		
		System.out.println("The Set: ");
		for (int i = 0; i < pop.get(0).gene.size(); i++) {
			if (pop.get(0).gene.get(i)==1) {
				System.out.println(items.get(i).lbl+" ");
			}
		}
		System.out.println();
		float usedCap = (pop.get(0).weight/(float)capacity)*100;
		System.out.println(usedCap+"% of the total capacity was used");
	}
	
}
